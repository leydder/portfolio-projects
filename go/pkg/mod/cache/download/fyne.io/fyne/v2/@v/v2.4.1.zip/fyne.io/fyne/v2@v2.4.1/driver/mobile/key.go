package mobile

import (
	"fyne.io/fyne/v2"
)

const (
	// KeyBack represents the back button which may be hardware or software
	KeyBack fyne.KeyName = "Back"
)
